# Crop Avatar

## Browser Support

- Chrome 34+
- Firefox 29+
- Internet Explorer 8+
- Opera 21+
- Safari 5.1+
