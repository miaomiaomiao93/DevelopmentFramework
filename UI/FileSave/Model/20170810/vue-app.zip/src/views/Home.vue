<template>
  <div>
    这是HOME
    <Hello></Hello>
  </div>
</template>

<script>
import Hello from '@/components/hello.vue'

export default {
  components: { Hello }
}
</script>

<style>

</style>
