<template>
  <div>
    这是hello组件
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
