﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace 统计在线人数
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            // 下载于www.mycodes.net
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        
            Session["name"] = TextBox1.Text;
            Response.Redirect("WebForm1.aspx");
        }
        
       
    }
}